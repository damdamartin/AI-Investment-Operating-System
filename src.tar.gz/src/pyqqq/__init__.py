"""PyQQQ - AI 자동매매 시스템"""
__version__ = "1.0.0"
